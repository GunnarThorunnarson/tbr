/* TODO
Search:
- bæta við x til að hreinsa leit 
- hægt sé að smella á hjálparorð sem klárast/færist í input
- sýna bara verkefni sem uppfylla leit.
*/

let nemaverkefni = [];
const el = document.getElementById("nemendaverkefni");
// const words = ["suppose end get","boy warrant general","natural. delightful","met sufficient projection ask.","decisively everything","principles if preference","do","impression","of. preserved oh so","difficult repulsive on","in household. in what","do","miss time be. valley","as be","appear","cannot so","by.","convinced resembled dependent","remainder led zealously","his shy own","belonging. always length","letter","adieus","add number moment she.","promise few","compass six several old","offices removal parties","fat. concluded","rapturous it intention","perfectly daughters","is as.","behaviour we","improving at something","to. evil true","high lady roof men","had open.","to projection considered it","precaution an","melancholy or.","wound young","you thing","worse along being ham.","dissimilar of favourable solicitude","if sympathize middletons","at. forfeited","up if disposing","perfectly in an","eagerness perceived necessary.","belonging sir","curiosity discovery","extremity yet","forfeited prevailed","own off.","travelling by","introduced of","mr terminated. knew as","miss","my high hope quit. in","curiosity shameless dependent","knowledge up.","literature admiration","frequently indulgence announcing","are who you","her. was","least quick after","six. so","it yourself repeated","together","cheerful. neither it cordial so","painful picture studied if.","sex","him position doubtful","resolved boy expenses.","her engrossed deficient","northward and neglected favourite newspaper.","but","use peculiar","produced concerns ten. maids","table how","learn","drift","but purse","stand yet"]
const formEl = document.querySelector('.leit #search')
const dropEl = document.querySelector('.leit .drop')
let words = [];


// Sækja JSON (bæta catch skilaboðin og bæta við spinner etc.)
async function getData() {
    let url = '/assets/verkefni/verkefni.json';
    try {
        let response = await fetch(url);
        let data = await response.json();
        let filterData = data.filter((v) => v.show == true);
        return filterData;
    } catch (error) {
        console.log(error);
    }
}

function renderTemplate() {
    const imgRoot = "/assets/images/verkefni/"
    let template = nemaverkefni.map( temp => { return `<a href="${temp.linkur}">
                <div class="verkefni3">
                    <img src="${imgRoot}${temp.mynd}" />	
                    <p class="fag"><strong>${temp.titill}</strong><br />${temp.afangaheiti}</p>	
                </div>
            </a>`;}).join('');
    el.innerHTML = template;
}

// Fisher-Yates shuffle
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1)); 
      [array[i], array[j]] = [array[j], array[i]];
    }
}

// fylki sem geymir leitarorð (byggt á gögnum úr JSON)
function searchArray(){ 
    nemaverkefni.forEach(ord => {
        words.push(ord.titill, ord.afangi, ord.afangaheiti, ...ord.flokkur);
    });
    return [...new Set(words)]; // remove duplicates, Set doesn't allow duplicate values
    // How to Remove Duplicates From a JavaScript Array: https://builtin.com/software-engineering-perspectives/remove-duplicates-from-array-javascript
    // words = tempWords.filter((value, index) => tempWords.indexOf(value) === index);  // ef ég vil nota objects
}

// Leitarreitur
const searchHandler = (e) => {
    const userInput = e.target.value.toLowerCase()

    if(userInput.length === 0) {
        dropEl.style.height = 0
        return dropEl.innerHTML = ''              
    }
    
    let filteredWords = words.filter(word => word.toLowerCase().includes(userInput)).sort().splice(0, 6);

    dropEl.innerHTML = ''
    
    filteredWords.forEach(item => {
        const listEl = document.createElement('li')
        listEl.textContent = item
        if(item === userInput) {
            listEl.classList.add('match')
        }
        dropEl.appendChild(listEl)
    })

    if(dropEl.children[0] === undefined) {
        return dropEl.style.height = 0
    }

    let totalChildrenHeight = dropEl.children[0].offsetHeight * filteredWords.length
    dropEl.style.height = totalChildrenHeight + 'px'
}
formEl.addEventListener('input', searchHandler)

async function setup(){
    nemaverkefni = await getData();
    shuffle(nemaverkefni);
    renderTemplate();
    words = searchArray();
  
}
setup();