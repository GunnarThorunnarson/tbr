let nemaverkefni = [];
const el = document.getElementById("nemendaverkefni");

// Sækja JSON (bæta catch skilaboðin og bæta við spinner etc.)
async function getData() {
    let url = '/assets/verkefni/verkefni.json';
    try {
        let response = await fetch(url);
        let data = await response.json();
        let filterData = data.filter((v) => v.show == true);
        return filterData;
    } catch (error) {
        console.log(error);
    }
}

function renderTemplate() {
    const imgRoot = "/assets/images/verkefni/"
    let template = nemaverkefni.map( temp => { return `<a href="${temp.linkur}">
                <div class="verkefni3">
                    <img src="${imgRoot}${temp.mynd}" />	
                    <p class="fag"><strong>${temp.titill}</strong><br />${temp.afangaheiti}</p>	
                </div>
            </a>`;}).join('');
    el.innerHTML = template;
}

// Fisher-Yates shuffle
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1)); 
      [array[i], array[j]] = [array[j], array[i]];
    }
}

async function main(){
    nemaverkefni = await getData();
    shuffle(nemaverkefni);
    renderTemplate();
}
main();