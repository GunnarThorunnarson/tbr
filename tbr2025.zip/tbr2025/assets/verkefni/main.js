/* TODO
Search:
- sýna bara verkefni sem uppfylla leit.
- Geyma/sleppa nota arrow (lyklaborð) til að fara niður listann (li í ul).
*/

let nemaverkefni = [];
const el = document.getElementById("nemendaverkefni");
const formEl = document.querySelector('.leit #search')
const dropEl = document.querySelector('.leit .drop')
const searchEl = document.querySelector(".input-wrapper button:first-child");

let words = [];

// Sækja JSON (bæta catch skilaboðin og bæta við spinner etc.)
async function getData() {
    let url = '/assets/verkefni/verkefni.json';
    try {
        let response = await fetch(url);
        let data = await response.json();
        let filterData = data.filter((v) => v.show == true);
        return filterData;
    } catch (error) {
        console.log(error);
    }
}

function renderTemplate() {
    const imgRoot = "/assets/images/verkefni/"
    let template = nemaverkefni.map( temp => { return `<a href="${temp.linkur}">
                <div class="verkefni3">
                    <img src="${imgRoot}${temp.mynd}" />	
                    <p class="fag"><strong>${temp.titill}</strong><br />${temp.afangaheiti}</p>	
                </div>
            </a>`;}).join('');
    el.innerHTML = template;
}

// Fisher-Yates shuffle
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1)); 
      [array[i], array[j]] = [array[j], array[i]];
    }
}

// fylki sem geymir leitarorð (byggt á gögnum úr JSON)
function searchArray(){ 
    nemaverkefni.forEach(ord => {
        words.push(ord.titill, ord.afangi, ord.afangaheiti, ...ord.flokkur);
    });
    return [...new Set(words)]; // remove duplicates, Set doesn't allow duplicate values
}

// Leitarreitur
const searchHandler = (e) => {
    const userInput = e.target.value.toLowerCase()

    if(userInput.length === 0) {
        dropEl.style.height = 0
        return dropEl.innerHTML = ''              
    }

    let filteredWords = words.filter(word => word.toLowerCase().includes(userInput)).sort().splice(0, 6);

    dropEl.innerHTML = ''
    filteredWords.forEach(item => {
        const listEl = document.createElement('li')
        listEl.textContent = item;
        if(item.toLowerCase() === userInput) {
            listEl.classList.add('match')
        }
        dropEl.appendChild(listEl)
    })

    if(dropEl.children[0] === undefined) {
        return dropEl.style.height = 0
    }

    let totalChildrenHeight = dropEl.children[0].offsetHeight * filteredWords.length
    dropEl.style.height = totalChildrenHeight + 'px'
}

function searchCloseHandler(e){
    if( e.target.nodeName.toLowerCase() === "li" ){   
        formEl.value = e.target.textContent;  // formEl.value = e.target.firstChild.nodeValue;
    }
    // of fljótur að loka og nær ekki að skrifa í input ef ég nota ekki timeout eða callback
    setTimeout(() => {
        dropEl.style.height = 0;
        formEl.focus();
    }, "100");
}

// Ef smellt á stækkunargler eða ENTER
function searchButtonHandler(e){
    e.preventDefault();
    setTimeout(() => {
        dropEl.style.height = 0;
        formEl.focus();
        // filter verkefni based on input
        console.log(formEl.value);

    }, "100");
}

async function setup(){
    nemaverkefni = await getData();
    shuffle(nemaverkefni);
    renderTemplate();
    words = searchArray();
  
}
setup();

formEl.addEventListener('input', searchHandler);        // listen to input value
formEl.addEventListener("blur", searchCloseHandler);    // tap from input
formEl.addEventListener("click", searchCloseHandler);   // click on input
dropEl.addEventListener("click", searchCloseHandler);   // click on li in ul
searchEl.addEventListener("click", searchButtonHandler);  // click on search button eða Enter
