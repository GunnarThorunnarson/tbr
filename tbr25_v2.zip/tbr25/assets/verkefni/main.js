// https://prasanthmj.github.io/typescript/serialize-javascript-objects/

let nemaverkefni = [];
const el = document.getElementById("nemendaverkefni");

// Sækja JSON (bæta catch skilaboðin og bæta við spinner etc.)
async function getData() {
    let url = '/assets/verkefni/verkefni.json';
    try {
        let response = await fetch(url);
        let data = await response.json();
        let filterData= data.filter((v) => v.show == true);
        return filterData;
    } catch (error) {
        console.log(error);
    }
}

async function main(){
    nemaverkefni = await getData();
    // búa til objecta með instance af class.
    showTemplate();

    // nemaverkefni.sort((a, b) => parseFloat(a.id) - (b.id)); // raða eftir verði
}
main();

// filtering

// birtum template á verkefni.html
function showTemplate() {
    // keyrum í gegnum array og búum til streng
    let temp = ""; 
    nemaverkefni.forEach(verkefni => {
        console.log(verkefni);
        // temp += verkefni.template;
    });   
    el.innerHTML = temp;
}

/*
function template() {
    const imgRoot = "/assets/images/verkefni/"
    let temp = `<a href="${this.linkur}"><div class="verkefni3">
                    <img src="${imgRoot}${this.mynd}" />	
                    <p class="fag"><strong>${this.titill}</strong><br />${this.afangaheiti}</p>	
                </div>
            </a>`;
    return temp;
}
*/
