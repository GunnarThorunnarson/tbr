class Verkefni {
	
	constructor(jsonData) {
        this.id = jsonData.id;
        this.titill = jsonData.titill;
        this.linkur = jsonData.linkur;
        this.mynd = jsonData.mynd;
		this.hofundur = jsonData.hofundur;
		this.dagsetning = jsonData.dagsetning;
		this.afangi = jsonData.afangi;
		this.afangaheiti = jsonData.afangaheiti;
		this.flokkur = jsonData.flokkur;
		this.show = jsonData.show;
    }

	get template() {
		const imgRoot = "/assets/images/verkefni/"
		let temp = `<a href="${this.linkur}"><div class="verkefni3">
						<img src="${imgRoot}${this.mynd}" />	
						<p class="fag"><strong>${this.titill}</strong><br />${this.afangaheiti}</p>	
					</div>
				</a>`;
		return temp;
	}
}