
CSS stillingar skoða:
- afangar.html laga stærð hæð á mynd Vefþróun, cut á forritun
- laga menu í namskskra.is fer bakvið
- laga margin í mobile
- pop-up calander fer til hægri í 4000 px upplausn. ekki ef % eru notaðar en þá fara verkefna containera í klessu.


### Dagatal og dagsetningar
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date
ISO 8601 Format
YYYY-MM-DDTHH:mm:ss.sssZ
2012-04-23T18:25:43.511Z

sss is the millisecond, with three digits (000 to 999). Defaults to 000.
Z is the timezone offset, which can either be the literal character Z (indicating UTC), or + or - followed by HH:mm, the offset in hours and minutes from UTC.


date range pick með mánuði og ár
Notum: YYYY-MM
 dagsetning = new Date(2017,11); 
 // Fri Dec 01 2017 00:00:00 GMT+0000 (Greenwich Mean Time)
srká timestamp ef ekki er skráð handvirkt

Prófa:
monthSelectPlugin
https://flatpickr.js.org/plugins/
range: https://github.com/flatpickr/flatpickr/issues/1838
{ mode: 'range', dateFormat: 'd/m/y', plugins: [ new monthSelectPlugin({ shorthand: true, theme: "light" }) ], onChange: (selectedDates) =>{ console.log(selectedDates); } }
https://community.getgrist.com/t/how-to-get-monthly-date-range-and-only-months-on-date-column/134


example:
const event = new Date("August 19, 1975 23:15:30 UTC");
const jsonDate = event.toJSON();
console.log(jsonDate); // Expected output: "1975-08-19T23:15:30.000Z"
console.log(new Date(jsonDate).toUTCString()); // Expected output: "Tue, 19 Aug 1975 23:15:30 GMT"


### Leit
https://blog.avada.io/css/search-boxes#filter-search-box-dropdown-animation


### How to Remove Duplicates From a JavaScript Array: 
https://builtin.com/software-engineering-perspectives/remove-duplicates-from-array-javascript
