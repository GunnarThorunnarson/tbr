# tskoli.github.io

Vefsíða: [áfangar á tölvubraut Upplýsingatækniskólans](https://tskoli.github.io/)
