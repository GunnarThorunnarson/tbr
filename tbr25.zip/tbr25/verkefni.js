/*
{% include /verkefni/forritun.html %} 
{% include /verkefni/vefthroun.html %} 
{% include /verkefni/kerfisstjorn.html %} 
{% include /verkefni/leikjagerd.html %} 
{% include /verkefni/gagnasafnsfraedi.html %} 
{% include /verkefni/vidmotsthroun.html %} 
{% include /verkefni/verksmidja.html %} 
{% include /verkefni/velmenni.html %}
*/


/*
<a href="https://vefgrunnur.github.io/synidaemi/iframe.html">	
	<div class="verkefni3">
	<img src="https://tolvubraut.is/assets/images/verkefni/dude.jpg" />		
	<p class="fag"><strong>Lokaverkefni</strong><br />Vefþróun I</p>	
	</div>
</a>
*/

let url = "";
let imgRoot = "https://tolvubraut.is/assets/images/verkefni/";
let description = ""
