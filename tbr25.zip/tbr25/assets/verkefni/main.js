const nemaverkefni = [];
const el = document.getElementById("nemendaverkefni");

// sækjum Json og búum til object og sýnum
(function saekjaJson() {
    fetch("/assets/verkefni/verkefni.json")
        .then(res => res.json())
        .then(json => {
            json.filter(j => j.show)  
                .forEach(verkefni => nemaverkefni.push(new Verkefni(verkefni)));
            nemaverkefni.forEach(verkefni => {
                synaDiv(verkefni);
            });
            
        })
        .catch(e => console.log("villa:", e));
})();

// filtering

// birtum template á verkefni.html
function synaDiv(verkefni) {
    console.log(verkefni.template); 
    el.innerHTML = verkefni.template;      // birtir strengi?      

/*  const btn = document.createElement('button');
    btn.className = "afangar";
    btn.className += afangi.core ? " core" : "";
    if(afangi.bval === 1) btn.className += " bval1";
    btn.style.gridArea = afangi.id.split('0')[0];
    btn.id = afangi.id;
    btn.innerHTML = afangi.button;
    mainDiv.appendChild(btn);
    allirAfangar.push(btn);
*/
}
