class Verkefni {
	
	constructor(data) {
        this.id = data.id;
        this.titill = data.titill;
        this.linkur = data.linkur;
        this.mynd = data.mynd;
		this.hofundur = data.hofundur;
		this.dagsetning = data.dagsetning;
		this.afangi = data.afangi;
		this.afangaheiti = data.afangaheiti;
		this.flokkur = data.flokkur;
		this.show = data.show;
    }

	get template() {
		const imgRoot = "/assets/images/verkefni/"
		let temp = `<a href="${this.linkur}"><div class="verkefni3">
						<img src="${imgRoot}${this.mynd}" />	
						<p class="fag"><strong>${this.titill}</strong><br />${this.afangaheiti}</p>	
					</div>
				</a>`;
		return temp;
	}
}